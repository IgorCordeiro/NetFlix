package com.igorcordeiroszeremeta.netflixremake2;

public class Movie {

    private int coverUrl;

    public int getCoverUrl() {
        return coverUrl;
    }

    public void setCoverUrl(int coverUrl) {
        this.coverUrl = coverUrl;
    }
}
